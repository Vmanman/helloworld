package exception;

/**
 * 功能描述
 *
 * @author w00453985
 * @since 2020-11-13
 */
public class MyException extends Exception {
    private static final long serialVersionUID = -6672702507525718955L;
}