package optional;

import exception.MyException;
import model.User;

import java.util.Optional;

/**
 * 功能描述
 *
 * @author w00453985
 * @since 2020-11-13
 */
public class OptionalTest {
    private void testCreator(User in) {
        Optional<User> user = Optional.empty();

        User inUser = new User("wangwenxuan", 29);
        Optional<User> user2 = Optional.of(inUser);

        Optional<User> user3 = Optional.ofNullable(in);
    }

    public void testMapAndFlatMap() {
        User wangwenxuan = new User("wangwenxuan", 29);
        Optional<User> user = Optional.of(wangwenxuan);
        System.out.println(user.map(User::getName));
        System.out.println(user.flatMap(OptionalTest::getUserNameOpt));
    }

    private static Optional<String> getUserNameOpt(User user) {
        return Optional.of(user.getName());
    }

    public static void main(String[] args) throws MyException {
        OptionalTest demo = new OptionalTest();

        // 构造器
        User wangwenxuan = new User("wangwenxuan", 29);
        demo.testCreator(wangwenxuan);
        demo.testCreator(null);

        demo.testMapAndFlatMap();
        Optional<User> user = Optional.of(wangwenxuan);
        User var1 = user.orElseThrow(MyException::new);
        Optional<String> userOpt = user.map(User::getName);

        User wuzhiyong = new User("wuzhiyong", 27);
        User var2 = user.orElse(wuzhiyong);
    }
}